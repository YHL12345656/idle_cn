README.txt：idlelib 文件和 IDLE 菜单的索引。 IDLE 是 Python 的集成开发和
学习环境。用户文档是 Library Reference 的一部分，可通过选择 Help => IDLE Help 在 IDLE 中找到。
这个自述文件为空闲开发人员和好奇的用户记录了 idlelib。 IDLELIB FILES 按类别按字母顺序列出文件，并附有每个文
件的简短说明。 IDLE MENU 显示菜单树，用实现相应功能的模块或模块对象进行注释。这个文件是描述性的，不是规定性的，可
能有错误和遗漏，滞后于 idlelib 的变化。空闲菜单文件 不在空闲菜单中的实现文件被标记 (nim)。不推荐使
用的文件和对象作为结尾单独列出。
启动
-------
__init__.py  #导入，什么都不做
__main__.py  # -m, 启动 IDLE
idle.bat
idle.py
idle.pyw

履行
--------------
autocomplete.py   # Complete attribute names or filenames.
autocomplete_w.py # Display completions.
autoexpand.py     # Expand word with previous word in file.
browser.py        # Create module browser window.
calltip_w.py      # Display calltip.
calltips.py       # Create calltip text.
codecontext.py    # Show compound statement headers otherwise not visible.
colorizer.py      # Colorize text (nim)
config.py         # Load, fetch, and save configuration (nim).
configdialog.py   # Display user configuration dialogs.
config_help.py    # Specify help source in configdialog.
config_key.py     # Change keybindings.
dynoption.py      # Define mutable OptionMenu widget (nim).
debugobj.py       # Define class used in stackviewer.
debugobj_r.py     # Communicate objects between processes with rpc (nim).
debugger.py       # Debug code run from shell or editor; show window.
debugger_r.py     # Debug code run in remote process.
delegator.py      # Define base class for delegators (nim).
editor.py         # Define most of editor and utility functions.
filelist.py       # Open files and manage list of open windows (nim).
grep.py           # Find all occurrences of pattern in multiple files.
help.py           # Display IDLE's html doc.
help_about.py     # Display About IDLE dialog.
history.py        # Get previous or next user input in shell (nim)
hyperparser.py    # Parse code around a given index.
iomenu.py         # Open, read, and write files
macosx.py         # Help IDLE run on Macs (nim).
mainmenu.py       # Define most of IDLE menu.
multicall.py      # Wrap tk widget to allow multiple calls per event (nim).
outwin.py         # Create window for grep output.
paragraph.py      # Re-wrap multiline strings and comments.
parenmatch.py     # Match fenceposts: (), [], and {}.
pathbrowser.py    # Create path browser window.
percolator.py     # Manage delegator stack (nim).
pyparse.py        # Give information on code indentation
pyshell.py        # Start IDLE, manage shell, complete editor window
query.py          # Query user for information
redirector.py     # Intercept widget subcommands (for percolator) (nim).
replace.py        # Search and replace pattern in text.
rpc.py            # Commuicate between idle and user processes (nim).
rstrip.py         # Strip trailing whitespace.
run.py            # Manage user code execution subprocess.
runscript.py      # Check and run user code.
scrolledlist.py   # Define scrolledlist widget for IDLE (nim).
search.py         # Search for pattern in text.
searchbase.py     # Define base for search, replace, and grep dialogs.
searchengine.py   # Define engine for all 3 search dialogs.
stackviewer.py    # View stack after exception.
statusbar.py      # Define status bar for windows (nim).
tabbedpages.py    # Define tabbed pages widget (nim).
textview.py       # Define read-only text widget (nim).
tree.py           # Define tree widger, used in browsers (nim).
undo.py           # Manage undo stack.
windows.py        # Manage window list and define listed top level.
zoomheight.py     # Zoom window to full height of screen.

Configuration
-------------
config-extensions.def # Defaults for extensions
config-highlight.def  # Defaults for colorizing
config-keys.def       # Defaults for key bindings
config-main.def       # Defai;ts fpr font and geneal

Text
----
CREDITS.txt  # not maintained, displayed by About IDLE
HISTORY.txt  # NEWS up to July 2001
NEWS.txt     # commits, displayed by About IDLE
README.txt   # this file, displeyed by About IDLE
TODO.txt     # needs review
extend.txt   # about writing extensions
help.html    # copy of idle.html in docs, displayed by IDLE Help

Subdirectories
--------------
Icons        # small image files
idle_test    # files for human test and automated unit tests

Unused and Deprecated files and objects (nim)
---------------------------------------------
tooltip.py # unused



IDLE MENUS
顶级项目和大多数子菜单项目在主菜单中定义。扩展在活动时添加子菜单项。给出的名称在这些模块之一中找到，引用
，与“<<pseudoevent>>”配对。每个伪事件都绑定到一个事件处理程序。一些事件处理程序调用另一个
执行实际工作的函数。下面的注释旨在至少给出完成实际工作的模块。 'eEW' = editor.EditorWindow

File
  New File         # eEW.new_callback
  Open...          # iomenu.open
  Open Module      # eEw.open_module
  Recent Files
  Class Browser    # eEW.open_class_browser, browser.ClassBrowser
  Path Browser     # eEW.open_path_browser, pathbrowser
  ---
  Save             # iomenu.save
  Save As...       # iomenu.save_as
  Save Copy As...  # iomenu.save_a_copy
  ---
  Print Window     # iomenu.print_window
  ---
  Close            # eEW.close_event
  Exit             # flist.close_all_callback (bound in eEW)

Edit
  Undo             # undodelegator
  Redo             # undodelegator
  ---              # eEW.right_menu_event
  Cut              # eEW.cut
  Copy             # eEW.copy
  Paste            # eEW.past
  Select All       # eEW.select_all (+ see eEW.remove_selection)
  ---              # Next 5 items use searchengine; dialogs use searchbase
  Find             # eEW.find_event, search.SearchDialog.find
  Find Again       # eEW.find_again_event, sSD.find_again
  Find Selection   # eEW.find_selection_event, sSD.find_selection
  Find in Files... # eEW.find_in_files_event, grep
  Replace...       # eEW.replace_event, replace.ReplaceDialog.replace
  Go to Line       # eEW.goto_line_event
  Show Completions # autocomplete extension and autocompleteWidow (&HP)
  Expand Word      # autoexpand extension
  Show call tip    # Calltips extension and CalltipWindow (& Hyperparser)
  Show surrounding parens  # parenmatch (& Hyperparser)

Shell  # pyshell
  View Last Restart    # pyshell.PyShell.view_restart_mark
  Restart Shell        # pyshell.PyShell.restart_shell
  Interrupt Execution  # pyshell.PyShell.cancel_callback

Debug (Shell only)
  Go to File/Line
  debugger         # debugger, debugger_r, PyShell.toggle_debuger
  Stack Viewer     # stackviewer, PyShell.open_stack_viewer
  Auto-open Stack Viewer  # stackviewer

Format (Editor only)
  Indent Region    # eEW.indent_region_event
  Dedent Region    # eEW.dedent_region_event
  Comment Out Reg. # eEW.comment_region_event
  Uncomment Region # eEW.uncomment_region_event
  Tabify Region    # eEW.tabify_region_event
  Untabify Region  # eEW.untabify_region_event
  Toggle Tabs      # eEW.toggle_tabs_event
  New Indent Width # eEW.change_indentwidth_event
  Format Paragraph # paragraph extension
  ---
  Strip tailing whitespace  # rstrip extension

Run (Editor only)
  Python Shell     # pyshell
  ---
  Check Module     # runscript
  Run Module       # runscript

Options
  Configure IDLE   # eEW.config_dialog, configdialog
    (tabs in the dialog)
    Font tab       # config-main.def
    Highlight tab  # query, config-highlight.def
    Keys tab       # query, config_key, config_keys.def
    General tab    # config_help, config-main.def
    Extensions tab # config-extensions.def, corresponding .py
  ---
  Code Context (ed)# codecontext extension

Window
  Zoomheight       # zoomheight extension
  ---
  <open windows>   # windows

Help
  About IDLE       # eEW.about_dialog, help_about.AboutDialog
  ---
  IDLE Help        # eEW.help_dialog, helpshow_idlehelp
  Python Doc       # eEW.python_docs
  Turtle Demo      # eEW.open_turtle_demo
  ---
  <other help sources>

<Context Menu> (right click)
  Defined in editor, PyShelpyshellut
    Cut
    Copy
    Paste
    ---
    Go to file/line (shell and output only)
    Set Breakpoint (editor only)
    Clear Breakpoint (editor only)
  Defined in debugger
    Go to source line
    Show stack frame

<No menu>
Center Insert      # eEW.center_insert_event


CODE STYLE -- 一般为 PEP 8。

import
------
除非有充分的理由，否则将 import 放在顶部。 PEP 8 说要对 stdlib、第 3 方依赖项和包导入进行分组。对于 idlelib，这些组
是通用的 stdlib、tkinter 和 idlelib。对每个组内的模块进行排序，除了 tkinter.ttk 跟在 tkinter 之后。按模
块对“from idlelib import mod1”和“from idlelib.mod2 import object”进行排序，忽略模块对象内。将
 'import __main__' 放在其他 idlelib 导入之后。
仅用于测试的导入不会放在顶部，而是放在 htest 函数 def 或“if __name__ == '__main__'”子句
中。像“from idlelib.mod import class”这样的模块导入可能会导致循环导入死锁。即使没有这个
，循环导入可能需要至少一个导入被延迟直到函数调用。