"""Define the menu contents, hotkeys, and event bindings.

There is additional configuration information in the EditorWindow class (and
subclasses): the menus are created there based on the menu_specs (class)
variable, and menus not created are silently skipped in the code here.  This
makes it possible, for example, to define a Debug menu which is only present in
the PythonShell window, and a Format menu which is only present in the Editor
windows.

"""
from importlib.util import find_spec

from idlelib.config import idleConf
#   Warning: menudefs is altered in macosx.overrideRootMenu()
#   after it is determined that an OS X Aqua Tk is in use,
#   which cannot be done until after Tk() is first called.
#   Do not alter the 'file', 'options', or 'help' cascades here
#   without altering overrideRootMenu() as well.
#       TODO: Make this more robust

menudefs = [
 # underscore prefixes character to underscore
 ('file', [
   ('新建（_N）', '<<open-new-window>>'),
   ('打开...（_O）', '<<open-window-from-file>>'),
   ('打开模块...（_M）', '<<open-module>>'),
   ('模块浏览器（_B）', '<<open-class-browser>>'),
   ('路径浏览器（_P）', '<<open-path-browser>>'),
   None,
   ('保存（_S）...', '<<save-window>>'),
   ('另存为...（_A）', '<<save-window-as-file>>'),
   ('保存副本...（_C）', '<<save-copy-of-window-as-file>>'),
   None,
   ('打印（_R）', '<<print-window>>'),
   None,
   ('关闭此窗口（_C）', '<<close-window>>'),
   ('关闭所有窗口（_X）', '<<close-all-windows>>'),
  ]),
 ('edit', [
   ('撤销（_U）', '<<undo>>'),
   ('重做（_R）', '<<redo>>'),
   None,
   ('剪切（_U）', '<<cut>>'),
   ('复制（_C）', '<<copy>>'),
   ('粘贴（_P）', '<<paste>>'),
   ('全选（_A）', '<<select-all>>'),
   None,
   ('查找...（_F）', '<<find>>'),
   ('再次查找（_G）', '<<find-again>>'),
   ('查找选择的内容（_S）', '<<find-selection>>'),
   ('在文件中查找...', '<<find-in-files>>'),
   ('替换...（_E）', '<<replace>>'),
   ('切换行（_L）', '<<goto-line>>'),
   ('自动补全（_H）', '<<force-open-completions>>'),
   ('补全单词（_X）', '<<expand-word>>'),
   ('显示参数帮助（_A）', '<<force-open-calltip>>'),
   ('选择参数部分（_A）', '<<flash-paren>>'),

  ]),
('format', [
   ('缩进（_I）', '<<indent-region>>'),
   ('反缩进（_D）', '<<dedent-region>>'),
   ('禁用此行（_O）', '<<comment-region>>'),
   ('启用此行（_N）', '<<uncomment-region>>'),
   ('统一缩进符', '<<tabify-region>>'),
   ('取消统一缩进符', '<<untabify-region>>'),
   ('切换缩进符', '<<toggle-tabs>>'),
   ('更改缩进宽度', '<<change-indentwidth>>'),
   ('格式化段落（_o）', '<<format-paragraph>>'),
   ('删除尾随的空白字符（_T）', '<<do-rstrip>>'),
   ]),
 ('run', [
   ('Python Shell', '<<open-python-shell>>'),
   ('检查（_H）', '<<check-module>>'),
   ('运行（_R）', '<<run-module>>'),
   ]),
 ('shell', [
   ('转到上一次运行（_V）', '<<view-restart>>'),
   ('重启Shell（_R）', '<<restart-shell>>'),
   None,
   ('强制终止（_I）', '<<interrupt-execution>>'),
   ]),
 ('debug', [
   ('前往其他文件中的行（_G）', '<<goto-file-line>>'),
   ('!调试器（_D）', '<<toggle-debugger>>'),
   ('堆栈查看器（_S）', '<<open-stack-viewer>>'),
   ('!自动打开堆栈查看器（_A）', '<<toggle-jit-stack-viewer>>'),
   ]),
 ('options', [
   ('设置（_I）', '<<open-config-dialog>>'),
   ('显示代码上下文（_C）', '<<toggle-code-context>>'),
   ]),
 ('windows', [
   ('缩放高度', '<<zoom-height>>'),
   ]),
 ('help', [
   ('关于Idle（_A）', '<<about-idle>>'),
   None,
   ('Idle的帮助（_H）', '<<help>>'),
   ('Python文档（_D）', '<<python-docs>>'),
   ]),
]

if find_spec('turtledemo'):
    menudefs[-1][1].append(('使用Turtle创建的示例', '<<open-turtle-demo>>'))

default_keydefs = idleConf.GetCurrentKeySet()
